import React, { createContext, useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const storedUser = await AsyncStorage.getItem("user");
        if (storedUser) setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error("Failed to load user data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);
 
  const login = async (email, password) => {
    try {
      const response = await fetch("http://192.168.248.134:5000/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const { user } = await response.json();
        await AsyncStorage.setItem("user", JSON.stringify(user));
        setUser(user);
      } else {
        throw new Error("Invalid email or password");
      }
    } catch (error) {
      alert(error.message);
    }
  };

  const signup = async (firstName, lastName, email, password, phoneNumber) => {
    try {
        console.log("Sending Signup Request:", { firstName, lastName, email, password, phoneNumber }); // Debugging line
      const response = await fetch("http://192.168.248.134:5000/api/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ firstName, lastName, email, password, phoneNumber }),
      });
      console.log("Response Status:", response.status); // Debugging line

      if (response.ok) {
        const { user } = await response.json();
        await AsyncStorage.setItem("user", JSON.stringify(user));
        setUser(user);
      } else {
        throw new Error("Failed to sign up");
      }
    } catch (error) {
      alert(error.message);
    }
  };

  const logout = async () => {
    try {
      await AsyncStorage.removeItem("user");
      setUser(null);
    } catch (error) {
      console.error("Logout Error:", error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
